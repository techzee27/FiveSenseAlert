Emergency Alert Application

SETUP INSTRUCTIONS:

1. Install Python 3.11 or higher

2. Install dependencies:
   pip install -r requirements.txt

3. Set up environment variables (create .env file or set them in your system):
   - WHATSAPP_PHONE_NUMBER_ID: Your WhatsApp Business Phone Number ID
   - WHATSAPP_ACCESS_TOKEN: Your WhatsApp Cloud API access token
   - WHATSAPP_RECIPIENT_NUMBER: The number that receives emergency alerts

4. Install FFmpeg (required for video conversion):
   - Ubuntu/Debian: sudo apt-get install ffmpeg
   - macOS: brew install ffmpeg
   - Windows: Download from https://ffmpeg.org/download.html

5. Run the application:
   python app.py

6. Open your browser and navigate to:
   http://localhost:5000

7. Allow camera and location permissions when prompted

8. Show 5 fingers to trigger emergency alert

WHATSAPP CLOUD API SETUP:

1. Go to https://developers.facebook.com/
2. Create a new app or use existing one
3. Add WhatsApp product to your app
4. Get your Phone Number ID from the API settings
5. Generate a permanent access token
6. Add a recipient phone number in WhatsApp format (e.g., 1234567890)

For more information, visit: https://developers.facebook.com/docs/whatsapp/cloud-api/

HOW IT WORKS:

- Camera starts automatically when you open the app
- MediaPipe Hands detects when you show 5 fingers
- Automatically records 5-second video
- Captures your GPS location
- Sends emergency message with video and location to WhatsApp
- Shows success confirmation

FEATURES:

✓ Real-time AI hand gesture detection
✓ Automatic video recording
✓ GPS location capture
✓ WhatsApp integration with video and location
✓ Visual feedback and status updates
✓ Automatic video format conversion (WebM to MP4)

TECHNOLOGY STACK:

Backend: Flask (Python)
Frontend: HTML5, CSS3, JavaScript
AI: MediaPipe Hands
Video: MediaRecorder API, FFmpeg
Geolocation: Browser Geolocation API
Messaging: WhatsApp Cloud API
